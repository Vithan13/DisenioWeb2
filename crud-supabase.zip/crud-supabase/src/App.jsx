import React from 'react'
import UsuarioCRUD from './components/UsuarioCRUD'
import './App.css'

function App() {
  return (
    <div className="App">
      <UsuarioCRUD />
    </div>
  )
}

export default App