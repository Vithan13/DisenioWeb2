import { useState, useEffect } from 'react'
import { supabase } from '../lib/supabase'

export const useUsuarios = () => {
  const [usuarios, setUsuarios] = useState([])
  const [cargos, setCargos] = useState([])
  const [loading, setLoading] = useState(false)

  // Obtener todos los usuarios con sus cargos
  const fetchUsuarios = async () => {
    setLoading(true)
    const { data, error } = await supabase
      .from('vista_usuarios_cargos')
      .select('*')
    
    if (!error) setUsuarios(data || [])
    setLoading(false)
    return { data, error }
  }

  // Obtener todos los cargos
  const fetchCargos = async () => {
    const { data, error } = await supabase
      .from('cargos')
      .select('*')
    
    if (!error) setCargos(data || [])
    return { data, error }
  }

  // Agregar usuario
  const agregarUsuario = async (usuarioData) => {
    const { nombre, email, id_cargo, fecha_inicio } = usuarioData
    
    // Insertar usuario
    const { data: usuario, error: errorUsuario } = await supabase
      .from('usuarios')
      .insert([{ nombre, email }])
      .select()
      .single()

    if (errorUsuario) return { error: errorUsuario }

    // Asignar cargo
    const { error: errorCargo } = await supabase
      .from('cargos_usuarios')
      .insert([{ 
        id_usuario: usuario.id, 
        id_cargo, 
        fecha_inicio 
      }])

    if (errorCargo) return { error: errorCargo }

    await fetchUsuarios()
    return { success: true }
  }

  // Eliminar usuario
  const eliminarUsuario = async (id) => {
    const { error } = await supabase
      .from('usuarios')
      .delete()
      .eq('id', id)

    if (!error) await fetchUsuarios()
    return { error }
  }

  // Modificar usuario
  const modificarUsuario = async (id, usuarioData) => {
    const { nombre, email, id_cargo } = usuarioData
    
    // Actualizar usuario
    const { error: errorUsuario } = await supabase
      .from('usuarios')
      .update({ nombre, email })
      .eq('id', id)

    if (errorUsuario) return { error: errorUsuario }

    // Actualizar cargo si se proporciona
    if (id_cargo) {
      const { error: errorCargo } = await supabase
        .from('cargos_usuarios')
        .update({ id_cargo })
        .eq('id_usuario', id)

      if (errorCargo) return { error: errorCargo }
    }

    await fetchUsuarios()
    return { success: true }
  }

  // Consultas específicas
  const usuariosPorCargo = async (cargoId) => {
    const { data, error } = await supabase
      .from('vista_usuarios_cargos')
      .select('*')
      .eq('id', cargoId)
    
    return { data, error }
  }

  const usuariosSueldoMayor = async (monto) => {
    const { data, error } = await supabase
      .from('vista_usuarios_cargos')
      .select('*')
      .gt('sueldo', monto)
    
    return { data, error }
  }

  const usuariosSueldoEntre = async (min, max) => {
    const { data, error } = await supabase
      .from('vista_usuarios_cargos')
      .select('*')
      .gte('sueldo', min)
      .lte('sueldo', max)
    
    return { data, error }
  }

  const usuariosLlegaronTarde = async () => {
    const { data, error } = await supabase
      .from('vista_usuarios_tarde')
      .select('*')
    
    return { data, error }
  }

  const usuariosSalieronTemprano = async () => {
    const { data, error } = await supabase
      .from('vista_usuarios_temprano')
      .select('*')
    
    return { data, error }
  }

  useEffect(() => {
    fetchUsuarios()
    fetchCargos()
  }, [])

  return {
    usuarios,
    cargos,
    loading,
    fetchUsuarios,
    agregarUsuario,
    eliminarUsuario,
    modificarUsuario,
    usuariosPorCargo,
    usuariosSueldoMayor,
    usuariosSueldoEntre,
    usuariosLlegaronTarde,
    usuariosSalieronTemprano
  }
}