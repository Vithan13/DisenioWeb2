import React, { useState } from 'react'
import { useUsuarios } from '../hooks/useUsuarios'

const UsuarioCRUD = () => {
  const {
    usuarios,
    cargos,
    loading,
    agregarUsuario,
    eliminarUsuario,
    modificarUsuario,
    usuariosPorCargo,
    usuariosSueldoMayor,
    usuariosSueldoEntre,
    usuariosLlegaronTarde,
    usuariosSalieronTemprano
  } = useUsuarios()

  const [formData, setFormData] = useState({
    nombre: '',
    email: '',
    id_cargo: '',
    fecha_inicio: new Date().toISOString().split('T')[0]
  })
  const [editando, setEditando] = useState(null)
  const [resultadosConsulta, setResultadosConsulta] = useState([])
  const [montoConsulta, setMontoConsulta] = useState(4000)

  const handleSubmit = async (e) => {
    e.preventDefault()
    
    if (editando) {
      await modificarUsuario(editando, formData)
    } else {
      await agregarUsuario(formData)
    }
    
    setFormData({
      nombre: '',
      email: '',
      id_cargo: '',
      fecha_inicio: new Date().toISOString().split('T')[0]
    })
    setEditando(null)
  }

  const handleEditar = (usuario) => {
    setFormData({
      nombre: usuario.nombre,
      email: usuario.email,
      id_cargo: usuario.id_cargo || ''
    })
    setEditando(usuario.id)
  }

  const handleCancelar = () => {
    setFormData({
      nombre: '',
      email: '',
      id_cargo: '',
      fecha_inicio: new Date().toISOString().split('T')[0]
    })
    setEditando(null)
  }

  // Funciones para las consultas
  const ejecutarConsulta = async (consultaFunc, ...args) => {
    const { data } = await consultaFunc(...args)
    setResultadosConsulta(data || [])
  }

  if (loading) return <div>Cargando...</div>

  return (
    <div style={{ padding: '20px', maxWidth: '1200px', margin: '0 auto' }}>
      <h1>CRUD de Usuarios</h1>
      
      {/* Formulario */}
      <form onSubmit={handleSubmit} style={{ marginBottom: '30px', padding: '20px', border: '1px solid #ccc' }}>
        <h2>{editando ? 'Editar Usuario' : 'Agregar Usuario'}</h2>
        
        <div style={{ marginBottom: '10px' }}>
          <input
            type="text"
            placeholder="Nombre"
            value={formData.nombre}
            onChange={(e) => setFormData({...formData, nombre: e.target.value})}
            required
            style={{ marginRight: '10px', padding: '5px' }}
          />
          
          <input
            type="email"
            placeholder="Email"
            value={formData.email}
            onChange={(e) => setFormData({...formData, email: e.target.value})}
            required
            style={{ marginRight: '10px', padding: '5px' }}
          />
        </div>
        
        <div style={{ marginBottom: '10px' }}>
          <select
            value={formData.id_cargo}
            onChange={(e) => setFormData({...formData, id_cargo: e.target.value})}
            required
            style={{ marginRight: '10px', padding: '5px' }}
          >
            <option value="">Seleccionar cargo</option>
            {cargos.map(cargo => (
              <option key={cargo.id} value={cargo.id}>
                {cargo.cargo} - Bs. {cargo.sueldo}
              </option>
            ))}
          </select>
          
          <input
            type="date"
            value={formData.fecha_inicio}
            onChange={(e) => setFormData({...formData, fecha_inicio: e.target.value})}
            required
            style={{ padding: '5px' }}
          />
        </div>
        
        <button type="submit" style={{ marginRight: '10px', padding: '5px 10px' }}>
          {editando ? 'Actualizar' : 'Agregar'}
        </button>
        
        {editando && (
          <button type="button" onClick={handleCancelar} style={{ padding: '5px 10px' }}>
            Cancelar
          </button>
        )}
      </form>

      {/* Consultas */}
      <div style={{ marginBottom: '30px', padding: '20px', border: '1px solid #ccc' }}>
        <h2>Consultas Especiales</h2>
        
        <div style={{ marginBottom: '10px' }}>
          <label>Monto de consulta: </label>
          <input
            type="number"
            value={montoConsulta}
            onChange={(e) => setMontoConsulta(Number(e.target.value))}
            style={{ margin: '0 10px', padding: '5px' }}
          />
        </div>
        
        <div style={{ display: 'flex', gap: '10px', flexWrap: 'wrap' }}>
          <button onClick={() => ejecutarConsulta(usuariosSueldoMayor, montoConsulta)}>
            Sueldo mayor a Bs. {montoConsulta}
          </button>
          
          <button onClick={() => ejecutarConsulta(usuariosSueldoEntre, 3000, 6000)}>
            Sueldo entre Bs. 3000-6000
          </button>
          
          <button onClick={() => ejecutarConsulta(usuariosLlegaronTarde)}>
            Llegaron tarde
          </button>
          
          <button onClick={() => ejecutarConsulta(usuariosSalieronTemprano)}>
            Salieron temprano
          </button>
          
          <button onClick={() => setResultadosConsulta(usuarios)}>
            Mostrar todos
          </button>
        </div>
      </div>

      {/* Tabla de resultados */}
      <div>
        <h2>
          {resultadosConsulta.length > 0 ? 'Resultados de la Consulta' : 'Todos los Usuarios'}
          ({resultadosConsulta.length || usuarios.length} registros)
        </h2>
        
        <table style={{ width: '100%', borderCollapse: 'collapse' }}>
          <thead>
            <tr style={{ backgroundColor: '#f5f5f5' }}>
              <th style={{ border: '1px solid #ddd', padding: '8px' }}>ID</th>
              <th style={{ border: '1px solid #ddd', padding: '8px' }}>Nombre</th>
              <th style={{ border: '1px solid #ddd', padding: '8px' }}>Email</th>
              <th style={{ border: '1px solid #ddd', padding: '8px' }}>Cargo</th>
              <th style={{ border: '1px solid #ddd', padding: '8px' }}>Sueldo (Bs.)</th>
              <th style={{ border: '1px solid #ddd', padding: '8px' }}>Acciones</th>
            </tr>
          </thead>
          <tbody>
            {(resultadosConsulta.length > 0 ? resultadosConsulta : usuarios).map(usuario => (
              <tr key={usuario.id}>
                <td style={{ border: '1px solid #ddd', padding: '8px' }}>{usuario.id}</td>
                <td style={{ border: '1px solid #ddd', padding: '8px' }}>{usuario.nombre}</td>
                <td style={{ border: '1px solid #ddd', padding: '8px' }}>{usuario.email}</td>
                <td style={{ border: '1px solid #ddd', padding: '8px' }}>{usuario.cargo}</td>
                <td style={{ border: '1px solid #ddd', padding: '8px' }}>{usuario.sueldo}</td>
                <td style={{ border: '1px solid #ddd', padding: '8px' }}>
                  <button 
                    onClick={() => handleEditar(usuario)}
                    style={{ marginRight: '5px', padding: '3px 6px' }}
                  >
                    Editar
                  </button>
                  <button 
                    onClick={() => eliminarUsuario(usuario.id)}
                    style={{ padding: '3px 6px', backgroundColor: '#ff4444', color: 'white' }}
                  >
                    Eliminar
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}

export default UsuarioCRUD